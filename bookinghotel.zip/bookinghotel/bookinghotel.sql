-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: bookinghotel
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `booking`
--

DROP TABLE IF EXISTS `booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `amount_room` double DEFAULT NULL,
  `amount_service` double DEFAULT NULL,
  `cccd` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` time(6) DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `num_date` int DEFAULT NULL,
  `pay_date` date DEFAULT NULL,
  `pay_status` tinyint DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK7udbel7q86k041591kj6lfmvw` (`user_id`),
  CONSTRAINT `FK7udbel7q86k041591kj6lfmvw` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking`
--

LOCK TABLES `booking` WRITE;
/*!40000 ALTER TABLE `booking` DISABLE KEYS */;
INSERT INTO `booking` VALUES (2,6790000,NULL,'342343','2025-03-21','07:06:47.305000','2025-03-21','Trần văn hiếu','no',1,'2025-03-21',1,'0987123123','2025-03-22',3),(3,6790000,NULL,'342343','2025-03-21','07:06:50.501000','2025-03-21','Trần văn hiếu','no',1,NULL,0,'0987123123','2025-03-22',3),(4,800000,NULL,'342343','2025-03-21','07:08:19.376000','2025-03-21','Trần văn hiếu','no',1,NULL,0,'0987123123','2025-03-22',3),(5,13580000,NULL,'342343','2025-03-21','17:06:47.408000','2025-03-24','Trần văn hiếu','gọi lại cho tôi',2,NULL,0,'0987123123','2025-03-26',4),(6,1106000,NULL,'23132345454366','2025-03-23','17:59:46.735000','2025-03-23','duy','',1,'2025-03-23',1,'0888664567','2025-03-24',1);
/*!40000 ALTER TABLE `booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_room`
--

DROP TABLE IF EXISTS `booking_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_room` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `from_date` date DEFAULT NULL,
  `num_day` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `booking_id` bigint DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9umnt0pjb1nf83qwoqry1cuc2` (`booking_id`),
  KEY `FK4e002f18klgu08ekxnav2rwr9` (`room_id`),
  CONSTRAINT `FK4e002f18klgu08ekxnav2rwr9` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `FK9umnt0pjb1nf83qwoqry1cuc2` FOREIGN KEY (`booking_id`) REFERENCES `booking` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_room`
--

LOCK TABLES `booking_room` WRITE;
/*!40000 ALTER TABLE `booking_room` DISABLE KEYS */;
INSERT INTO `booking_room` VALUES (2,'2025-03-21',1,6790000,'2025-03-22',2,1),(3,'2025-03-21',1,6790000,'2025-03-22',3,1),(4,'2025-03-21',1,800000,'2025-03-22',4,2),(5,'2025-03-24',2,6790000,'2025-03-26',5,1),(6,'2025-03-23',1,1106000,'2025-03-24',6,3);
/*!40000 ALTER TABLE `booking_room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Đà Lạt'),(2,'Hạ Long'),(3,'Phú Quốc'),(4,'Nha Trang'),(7,'Hà Nội'),(8,'Bình Dương'),(10,'Huế');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `comment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `created_time` time(6) DEFAULT NULL,
  `star` float DEFAULT NULL,
  `hotel_id` bigint DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKej6lhabpn9qvujgc51lqlkmur` (`hotel_id`),
  KEY `FKqm52p1v3o13hy268he0wcngr5` (`user_id`),
  CONSTRAINT `FKej6lhabpn9qvujgc51lqlkmur` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`),
  CONSTRAINT `FKqm52p1v3o13hy268he0wcngr5` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` VALUES (4,'khách sạn sạch sẽ','2025-03-21','17:26:40.285000',4,4,'0981231242','Trần Văn Nam','nam@gmail.com',NULL),(5,'phục vụ kém','2025-03-21','17:27:07.347000',2,4,'0971231243','Hoàng văn tú','tu@gmail.com',NULL),(6,'Dịch vụ phòng tốt, buffer sáng rất ngon.','2025-03-23','17:52:51.438000',4,5,'0888664578','Duy','abvc@gmail.com',NULL),(7,'We had a Nice and pleasant stay. Very well mannered and helpful staffs. The salt coffee they served was one the best we had in all Hanoi.','2025-03-23','20:30:32.473000',5,12,'0192847586','Lerk','lerk@gmail.com',NULL),(8,'Great hotel with a beautiful view of the city. Friendly and helpful staff. I mistakenly booked a room with a view of the street, without any problems they immediately offered to change it to a room with a view of the city. The rooms are clean, the...','2025-03-23','20:31:46.339000',5,11,'0992867462','Leilamyratovna','leilamy2099@gmail.com',NULL),(9,'staff are helpful that help us to check in early when rooms available.\n- the location is right in the centre but the room is spacious\n- super clean, good smell','2025-03-23','20:33:00.294000',4,9,'0881375632','Trọng Ngô','Trongngo291@gmail.com',NULL),(10,' facilities is okay, great staff. The location is so far market','2025-03-23','20:34:58.258000',2,11,'0987124657','Long Le','longlekhanh1354@gmail.com',NULL),(11,'The hostess is cute and friendly. The room is spacious, the interior is dirty and bad smell room','2025-03-23','20:36:52.469000',2,1,'0887794146','Khoa Nguyen','khoasecuri@gmail.com',NULL),(12,'Good location near the train station, yet tucked away in a noisy street','2025-03-23','20:38:20.414000',3,13,'0988573813','Jay Smith','Jaysonsmith091@gmail.com',NULL),(13,'The location was perfect, and close to the beach and esplanade, restaurants and markets. Breakfast was great. Oceanview room was amazing. Amazing views. Bathroom also has oceanviews. Room very spacious and comfortable and quiet','2025-03-23','20:42:27.180000',4,13,'0882745813','Phong Nguyen','phongsuper821@gmail.com',NULL),(14,'Hotel is comfort, you have everything you need. Rooms are big and they have bife breakfast. People are kind and we had a wonderful stay there. I recomend this hotel everyone who want to see Hue and','2025-03-23','20:50:23.953000',4,14,'0987164424','Vladosa','vladosason@gmail.com',NULL);
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel`
--

DROP TABLE IF EXISTS `hotel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `avg_price` double DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `num_rating` int DEFAULT NULL,
  `star` float DEFAULT NULL,
  `category_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcwvmmtpfa1hsm8gwya0k0hmfk` (`category_id`),
  CONSTRAINT `FKcwvmmtpfa1hsm8gwya0k0hmfk` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel`
--

LOCK TABLES `hotel` WRITE;
/*!40000 ALTER TABLE `hotel` DISABLE KEYS */;
INSERT INTO `hotel` VALUES (1,'Hà Nội - Trung Quốc - Bắc Kinh - Thượng Hải - Hàng Châu',900000,'<p>hehe oke</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210107/awxv0qfq5heabpi8vrq7.jpg','Khách sạn Hạ Long gold 5 sao',0,2,2),(3,'51 Nam Kỳ Khởi Nghĩa , Quận 1 , Đà lạt',6790000,'<p>tgeg</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210140/zbs2mjbzsjvkfqkdmpur.jpg','King Palace Hotel',0,0,1),(4,'21 A trương định, Phú Quốc',2490000,'<p><strong>Vị tr&iacute;</strong><br>Kh&aacute;ch sạn Shinjuku Washington Hotel Main l&agrave; một kh&aacute;ch sạn ở khu vực tốt, nằm tại Shinjuku.</p>\n<p><strong>Giới thiệu về Kh&aacute;ch sạn Shinjuku Washington Hotel Main</strong></p>\n<p>H&atilde;y sẵn s&agrave;ng để c&oacute; được trải nghiệm lưu tr&uacute; kh&oacute; qu&ecirc;n với dịch vụ độc quyền của kh&aacute;ch sạn, được ho&agrave;n thiện bởi đầy đủ c&aacute;c tiện nghi để đ&aacute;p ứng mọi nhu cầu của bạn.</p>\n<p>Quầy lễ t&acirc;n 24 giờ lu&ocirc;n sẵn s&agrave;ng phục vụ bạn, từ khi nhận ph&ograve;ng đến khi trả ph&ograve;ng, hoặc bất kỳ sự hỗ trợ n&agrave;o bạn cần. Nếu bạn muốn th&ecirc;m bất kỳ điều g&igrave;, đừng ngần ngại li&ecirc;n hệ với quầy lễ t&acirc;n, ch&uacute;ng t&ocirc;i lu&ocirc;n sẵn s&agrave;ng phục vụ bạn.</p>\n<p>Thưởng thức những m&oacute;n ăn y&ecirc;u th&iacute;ch của bạn với c&aacute;c m&oacute;n ăn đặc biệt từ Kh&aacute;ch sạn Shinjuku Washington Hotel Main d&agrave;nh ri&ecirc;ng cho bạn.</p>\n<p>Kh&aacute;ch sạn Shinjuku Washington Hotel Main l&agrave; một kh&aacute;ch sạn với sự thoải m&aacute;i tuyệt vời v&agrave; dịch vụ xuất sắc theo đ&aacute;nh gi&aacute; của hầu hết kh&aacute;ch lưu tr&uacute;.</p>\n<p>H&atilde;y tạo n&ecirc;n những khoảnh khắc qu&yacute; gi&aacute; v&agrave; kh&oacute; qu&ecirc;n trong suốt thời gian lưu tr&uacute; của bạn tại Kh&aacute;ch sạn Shinjuku Washington Hotel Main.</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210237/ccx05hj3mcnhby9o77uq.jpg','MerPerle Hotel',0,3,3),(5,'231 Đường Hoa Hồng Phường 4, Đà Lạt, Việt Nam',7279866,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742726527/qjlqbhrafmllivj97f88.png','Mơ Stay',0,4,1),(9,'2 Nguyen Thi Minh Khai Street, Loc Tho Ward, Nha Trang',1862000,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734464/rsxgjz8v3z3tmc22ydti.png','Panorama Hotel',0,4,4),(11,'6 Đống Đa,, Da Lat',1800000,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735697/goqfgjvkeiabpvb88xdt.png','New Life Hotel - Da Lat',0,3,1),(12,'No. 18, Dao Duy Tu Street, Hang Buom Ward, Hoan Kiem District, Hanoi',5000000,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735881/yay87ljq5h5wvyvo8n1e.png','La Palm Boutique Hotel',0,5,7),(13,'51 Nam Kỳ Khởi Nghĩa , Thủ Dầu Một , Bình Dương',1900000,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737259/ylaabewfvfon48bwiu2o.png','Le Parfum Apartment and Hotel',0,3,8),(14,'17 Nguyễn Huệ, Huế',2700000,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737562/nujkhvsfolzztn02zqro.png','Mondial Hotel Hue',0,4,10);
/*!40000 ALTER TABLE `hotel` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_image`
--

DROP TABLE IF EXISTS `hotel_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `hotel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK293ve9b0ocbfji4u5hl2oh3ks` (`hotel_id`),
  CONSTRAINT `FK293ve9b0ocbfji4u5hl2oh3ks` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_image`
--

LOCK TABLES `hotel_image` WRITE;
/*!40000 ALTER TABLE `hotel_image` DISABLE KEYS */;
INSERT INTO `hotel_image` VALUES (1,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742057633/gx1bzocoof08asyfbesd.jpg',1),(3,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742057633/nejdfhqqwre6kquiirss.jpg',1),(4,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742057633/zqp5wfjktb224ehprjxo.jpg',1),(5,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742057633/gpzjx85ve4otzysqvfko.jpg',1),(10,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742116295/erwi5r5rjgq0xn1ryols.jpg',3),(11,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742116295/g7dskqgtzpevsg6uaaeo.jpg',3),(12,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742116295/wgqgwuwiy2gtxgmdlpfi.jpg',3),(13,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742116295/aiwgnm49rgns9ubvxtl3.jpg',3),(14,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210239/hjeijicdhcxw9j8p77xf.jpg',4),(15,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210239/loxjsi9clt771ljajief.jpg',4),(16,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210239/tqwbplcrajqcsjydj3mb.jpg',4),(17,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210239/n1wijuwxu4hoirzqaugz.jpg',4),(18,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210240/qvjp5kntcyxqgof23wa3.jpg',4),(19,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742210240/a0vkglerqlpeen0yeyfw.jpg',4),(20,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742550885/rnwwgq7x8zx1nsl9lyfl.jpg',1),(21,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742550886/w3jrwjl0qcrfielmhgyt.jpg',1),(22,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742726562/evnc6p8xcq23f3xjbtso.png',5);
/*!40000 ALTER TABLE `hotel_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotel_utilities`
--

DROP TABLE IF EXISTS `hotel_utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotel_utilities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `hotel_id` bigint DEFAULT NULL,
  `utilities_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjv8qsx728xr6inv6i5dd11l6c` (`hotel_id`),
  KEY `FKgqwe30jgrtteeb5gf287mirx6` (`utilities_id`),
  CONSTRAINT `FKgqwe30jgrtteeb5gf287mirx6` FOREIGN KEY (`utilities_id`) REFERENCES `utilities` (`id`),
  CONSTRAINT `FKjv8qsx728xr6inv6i5dd11l6c` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotel_utilities`
--

LOCK TABLES `hotel_utilities` WRITE;
/*!40000 ALTER TABLE `hotel_utilities` DISABLE KEYS */;
INSERT INTO `hotel_utilities` VALUES (27,1,2),(28,1,4),(29,1,5),(30,1,9),(31,3,1),(32,3,2),(33,3,4),(34,3,7),(35,3,8),(36,3,10),(37,4,1),(38,4,3),(39,4,4),(40,4,5),(41,4,9),(42,5,1),(43,5,2),(44,5,3),(45,5,4),(46,5,5),(47,5,6),(48,5,7),(68,9,1),(69,9,2),(70,9,3),(71,9,5),(72,9,8),(73,9,10),(89,11,1),(90,11,2),(91,11,3),(92,11,4),(93,11,9),(94,11,10),(95,12,1),(96,12,2),(97,12,3),(98,12,4),(99,12,5),(100,12,7),(105,13,1),(106,13,2),(107,13,3),(108,13,4),(113,14,1),(114,14,2),(115,14,4),(116,14,6);
/*!40000 ALTER TABLE `hotel_utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `description` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `max_people` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `num_bed` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `hotel_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKdosq3ww4h9m2osim6o0lugng8` (`hotel_id`),
  CONSTRAINT `FKdosq3ww4h9m2osim6o0lugng8` FOREIGN KEY (`hotel_id`) REFERENCES `hotel` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,'<p>vreg</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119860/gmd9plv9btnbw0qquhlv.jpg',2,'Junior Suite with Terrace',1,6790000,4),(2,'<p>đ&acirc;y l&agrave; m&ocirc; tả</p>','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295762/qqhgcrenoumdggcahd6r.jpg',6,'Duplex Suite',4,800000,4),(3,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734896/zw1ckwsaoberyudlwhj7.png',2,'Phòng Deluxe Giường Đôi',1,1106000,5),(4,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734591/tgylzztzsl1xknd2txff.png',2,'Studio with Mountain View',1,1500000,9),(5,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734690/dlou0eu7dp5xkvazxox3.png',2,'Apartment with Sea View',1,2070000,9),(6,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742734802/becc4fzc5jnngrm5al5z.png',4,'Phòng Deluxe Giường Đôi',2,750000,5),(7,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735110/xfq6sbkcjvck6qknmenu.png',2,'Deluxe Double Room with Balcony',1,1200000,1),(8,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735240/augfsmsh9wwrlahdk7ld.png',4,'Family Room with Balcony',2,4000000,1),(9,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735357/nyhmczdxnrfbyxk1zomy.png',2,'Superior King Room',1,989000,3),(10,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735443/qar5kfmusislrfeoueti.png',4,'Deluxe Quadruple Room',2,3250000,3),(11,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742735987/i06johi059eauyabalzc.png',2,'Superior Double or Twin Room',1,5000000,12),(12,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736076/ffrcopzq8dhn2ywynnl8.png',3,'Deluxe Triple Room',2,800000,12),(13,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736239/ewdyqsfs2o0qz0hqdopx.png',6,'Deluxe Family Room',3,2300000,11),(14,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736435/h2lrtzaiudfl5hmnhyhm.png',2,'Standard Apartment',1,980000,13),(15,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742736552/uimu9z6ubxaqy2ytagge.png',4,'Two-Bedroom Apartment',2,1200000,13),(16,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737628/xoor6emvumjwgjq5qlhk.png',2,'Superior Double or Twin Room with City View',2,1900000,14),(17,'','http://res.cloudinary.com/dkc0ky8md/image/upload/v1742737739/moc7cg80zbhwgdgxhosh.png',2,'Suite River View',1,2500000,14);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_image`
--

DROP TABLE IF EXISTS `room_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_image` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `image` varchar(255) DEFAULT NULL,
  `room_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKcme41omxvwoj00bhqk7fwt70v` (`room_id`),
  CONSTRAINT `FKcme41omxvwoj00bhqk7fwt70v` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_image`
--

LOCK TABLES `room_image` WRITE;
/*!40000 ALTER TABLE `room_image` DISABLE KEYS */;
INSERT INTO `room_image` VALUES (1,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/wttuptoua9fkpfx9puod.jpg',1),(2,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/adsyqzm5nurknx6zlgly.jpg',1),(3,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/fj4xomf0kterwogv5xtb.jpg',1),(4,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742119861/vt4r1ceo2l9jeamrviqv.jpg',1),(5,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295764/n37znnkc1g9dmsgclytd.jpg',2),(6,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295764/g6jglplx5jhoubrxfdcb.jpg',2),(7,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742295764/hfvjglbw2wrifx9rzr33.jpg',2),(8,'http://res.cloudinary.com/dkc0ky8md/image/upload/v1742727355/vdt28qfevkb09ebtey2o.png',3);
/*!40000 ALTER TABLE `room_image` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_utilities`
--

DROP TABLE IF EXISTS `room_utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_utilities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `room_id` bigint DEFAULT NULL,
  `utility_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKgymhu6h1hawo02mk1lywlvt1m` (`room_id`),
  KEY `FKq0n1xboq4yonnp9rslciw6ye2` (`utility_id`),
  CONSTRAINT `FKgymhu6h1hawo02mk1lywlvt1m` FOREIGN KEY (`room_id`) REFERENCES `room` (`id`),
  CONSTRAINT `FKq0n1xboq4yonnp9rslciw6ye2` FOREIGN KEY (`utility_id`) REFERENCES `utilities` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_utilities`
--

LOCK TABLES `room_utilities` WRITE;
/*!40000 ALTER TABLE `room_utilities` DISABLE KEYS */;
INSERT INTO `room_utilities` VALUES (21,4,1),(22,4,2),(23,4,6),(24,4,9),(25,5,1),(26,5,2),(27,5,3),(28,5,7),(34,6,1),(35,6,3),(36,6,5),(37,6,6),(38,6,7),(39,3,2),(40,3,10),(41,1,1),(42,1,2),(43,1,4),(44,7,1),(45,7,2),(46,7,3),(47,7,4),(48,7,10),(49,8,1),(50,8,2),(51,8,3),(52,8,4),(53,8,5),(54,8,6),(55,8,7),(56,8,8),(57,9,1),(58,9,2),(59,9,3),(60,9,4),(61,9,7),(62,9,9),(63,10,1),(64,10,3),(65,10,4),(66,10,5),(67,10,9),(68,10,10),(69,2,1),(70,2,3),(71,2,4),(72,2,5),(73,11,1),(74,11,2),(75,11,4),(76,11,5),(77,12,2),(78,12,6),(79,12,7),(80,12,9),(81,13,1),(82,13,2),(83,13,3),(84,13,4),(85,13,5),(86,13,6),(87,13,7),(88,13,8),(89,13,9),(90,13,10),(91,14,1),(92,14,3),(93,14,8),(94,14,9),(95,15,1),(96,15,2),(97,15,3),(98,15,5),(99,15,7),(100,16,1),(101,16,2),(102,16,3),(103,16,5),(104,16,6),(105,16,7),(106,16,9),(107,16,10),(116,17,1),(117,17,3),(118,17,4),(119,17,5),(120,17,6),(121,17,7),(122,17,9),(123,17,10);
/*!40000 ALTER TABLE `room_utilities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `activation_key` varchar(255) DEFAULT NULL,
  `actived` bit(1) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `created_date` date DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `role` enum('ROLE_ADMIN','ROLE_USER') DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,_binary '',NULL,NULL,'admin@gmail.com','ADMIN','$2a$10$lgWN38DZcBkTP0LLTo7A3.X1RHQ631WQHkHPhFeBI4PADwhMpBYi6',NULL,'ROLE_ADMIN'),(3,NULL,_binary '\0',NULL,'2025-03-19','hieutran02102804@gmail.com',NULL,'$2a$10$uIvo0Hr8xhZKHwN9NoNYf.YHAVfmskPOadyONFtZdj8wlSb4XmjTS','0932478234','ROLE_USER'),(4,NULL,_binary '',NULL,'2025-03-21','duyngo288@gmail.com',NULL,'$2a$10$npOL77KCu0zsih.nXbr26uUZc2NfGHuL5UFnzpCtfe5jDG09Rvxsy','0981231232','ROLE_USER');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `utilities`
--

DROP TABLE IF EXISTS `utilities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `utilities` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `icon` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilities`
--

LOCK TABLES `utilities` WRITE;
/*!40000 ALTER TABLE `utilities` DISABLE KEYS */;
INSERT INTO `utilities` VALUES (1,'fa fa-wifi',NULL,'Wi-Fi miễn phí'),(2,'fa fa-bath',NULL,'Bồn tắm'),(3,'fas fa-tv',NULL,'Tivi'),(4,'fa fa-calendar',NULL,'Miễn phí hủy phòng'),(5,'fa fa-door-open',NULL,'Cửa sổ'),(6,'fa fa-smoking',NULL,'Có thể hút thuốc'),(7,'fas fa-hamburger',NULL,'Miễn phí bữa sáng'),(8,'fa fa-couch',NULL,'Sofa'),(9,'fa fa-chair',NULL,'Ghế massage'),(10,'fa fa-user',NULL,'Nhân viên 24/7');
/*!40000 ALTER TABLE `utilities` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-03-26 14:50:50
