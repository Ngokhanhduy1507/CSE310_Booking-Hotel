package com.web.service;

import com.web.dto.HotelDto;
import com.web.entity.*;
import com.web.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Service
public class HotelService {


    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private HotelImageRepository hotelImageRepository;

    @Autowired
    private HotelUtilitiesRepository hotelUtilitiesRepository;

    public Hotel save(HotelDto dto){
        if(dto.getHotel().getId() == null){
            dto.getHotel().setNumRating(0);
            dto.getHotel().setStar(0F);
        }
        else{
            Hotel h = hotelRepository.findById(dto.getHotel().getId()).get();
            dto.getHotel().setNumRating(h.getNumRating());
            dto.getHotel().setStar(h.getStar());
        }
        Hotel result = hotelRepository.save(dto.getHotel());
        for(String s : dto.getListImage()){
            HotelImage hotelImage = new HotelImage();
            hotelImage.setImage(s);
            hotelImage.setHotel(result);
            hotelImageRepository.save(hotelImage);
        }
        hotelUtilitiesRepository.deleteByHotel(result.getId());
        for(Long id : dto.getListUtilityId()){
            HotelUtilities hotelUtilities = new HotelUtilities();
            hotelUtilities.setHotel(result);
            Utilities utilities = new Utilities();
            utilities.setId(id);
            hotelUtilities.setUtilities(utilities);
            hotelUtilitiesRepository.save(hotelUtilities);
        }
        return result;
    }

    public List<Hotel> findAll (){
        List<Hotel> result = hotelRepository.findAll();
        return result;
    }

    public Page<Hotel> findAllPage (Pageable pageable,Long idCategory){
        Page<Hotel> result = null;
        if(idCategory == null){
            result = hotelRepository.findAll(pageable);
        }
        else{
            result = hotelRepository.findByCategory(idCategory,pageable);
        }
        return result;
    }

    public Hotel findById(Long id){
        return hotelRepository.findById(id).get();
    }

    public void delete(Long id){
        hotelRepository.deleteById(id);
    }


    public Page<Hotel> getAvailableHotels(Date fromDate, int numDays, List<Long> categoryIds, Pageable pageable) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(fromDate);
        calendar.add(Calendar.DAY_OF_MONTH, numDays);
        Date toDate = calendar.getTime();

        return hotelRepository.findAvailableHotels(fromDate, toDate, categoryIds, pageable);
    }
}
