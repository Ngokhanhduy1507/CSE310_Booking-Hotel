const exceptionCode = 417;

$( document ).ready(function() {
    loadFooter();
});
async function loadMenu() {
}


function loadFooter() {
    var foo = `<div class="container">
            <div class="row">
                <!-- Logo và đối tác -->
                <div class="col-md-4">
                    <h5 class="mb-3"></h5>
                    <button class="btn btn-outline-light btn-sm mb-3">Hợp tác với Booking Hotel</button>
                    <h6>Đối tác thanh toán</h6>
                    <div class="d-flex flex-wrap">
                        <img src="image/master.webp" alt="Mastercard" height="30" class="m-1">
                        <img src="image/visa.webp" alt="Visa" height="30" class="m-1">
                        <img src="image/momo.webp" alt="MoMo" height="30" class="m-1">
                        <img src="image/vietqr.webp" alt="VietQR" height="30" class="m-1">
                    </div>
                </div>
                
                <!-- Về Traveloka -->
                <div class="col-md-2">
                    <h6>Về Booking Hotel</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light">Cách đặt chỗ</a></li>
                        <li><a href="#" class="text-light">Liên hệ chúng tôi</a></li>
                        <li><a href="#" class="text-light">Trợ giúp</a></li>
                        <li><a href="#" class="text-light">Tuyển dụng</a></li>
                    </ul>
                </div>
    
                <!-- Sản phẩm -->
                <div class="col-md-2">
                    <h6>Sản phẩm</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light">Khách sạn</a></li>
                        <li><a href="#" class="text-light">Vé máy bay</a></li>
                        <li><a href="#" class="text-light">Vé xe khách</a></li>
                        <li><a href="#" class="text-light">Cho thuê xe</a></li>
                    </ul>
                </div>
                
                <!-- Mạng xã hội -->
                <div class="col-md-2">
                    <h6>Theo dõi chúng tôi</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light">Facebook</a></li>
                        <li><a href="#" class="text-light">Instagram</a></li>
                        <li><a href="#" class="text-light">TikTok</a></li>
                        <li><a href="#" class="text-light">YouTube</a></li>
                    </ul>
                </div>
                
                <!-- Ứng dụng -->
                <div class="col-md-2">
                    <h6>Tải ứng dụng Booking Hotel</h6>
                    <img src="image/ggpay.svg" alt="Google Play" height="40" class="d-block mb-2">
                    <img src="image/appstore.svg" alt="App Store" height="40">
                </div>
            </div>
        </div>`
    document.getElementById("footer").innerHTML = foo;
}

async function logout() {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    window.location.replace('login')
}


function formatmoney(money) {
    const VND = new Intl.NumberFormat('vi-VN', {
        style: 'currency',
        currency: 'VND',
    });
    return VND.format(money);
}
