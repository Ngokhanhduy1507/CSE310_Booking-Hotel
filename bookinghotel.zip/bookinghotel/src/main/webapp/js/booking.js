
async function createBooking() {
    var arr = [];
    for(i=0; i<listRoomArr.length; i++){
        arr.push(listRoomArr[i].id)
    }
    var bookingDto = {
        "fromDate": document.getElementById("fromdate").value,
        "numDate": document.getElementById("songay").value,
        "fullname": document.getElementById("hotendp").value,
        "phone": document.getElementById("phonedp").value,
        "cccd": document.getElementById("cccddp").value,
        "note": document.getElementById("ghichudp").value,
        "listRoomId": arr,
    }
    var url = 'http://localhost:8080/api/booking/public/create-booking';
    const res = await fetch(url, {
        method: 'POST',
        headers: new Headers({
            'Content-Type': 'application/json'
        }),
        body: JSON.stringify(bookingDto)
    });
    if (res.status < 300) {
        swal({
            title: "Thông báo",
            text: "Đặt phòng thành công!",
            type: "success"
        }, function() {
            window.location.reload();
        });
    }
    if (res.status == exceptionCode) {
        
    }

}


async function myBooking() {
    var url = 'http://localhost:8080/api/booking/user/my-booking';
    const response = await fetch(url, {
        method: 'POST'
    });
    var list = await response.json();
    var main = '';
    var total = 0;
    for(i=0; i<list.length; i++){
        total = Number(total)+Number(1)
        main +=
            `<tr>
            <td><a class="yls">#${list[i].id}</a></td>
            <td class="floatr">${list[i].createdTime} ${list[i].createdDate}</td>
            <td>${list[i].fromDate}</td>
            <td class="floatr">${list[i].numDate}</td>
            <td>${list[i].fullname}</td>
            <td class="floatr">${list[i].phone}</td>
            <td><span class="span_pending">${loadTrangThai(list[i].payStatus)}</span></td>
            <td class="floatr"><span class="span_"><span class="yls">${formatmoney(list[i].amountRoom)}</span></span></td>
            <td><button onclick="bookingRoomDetail(${list[i].id})" data-bs-toggle="modal" data-bs-target="#modaldeail" class="btn btn-primary">Chi tiết</button></td>
        </tr>`
    }
    document.getElementById("listBooking").innerHTML = main;
    document.getElementById("sldonhang").innerHTML = total+" đơn đặt phòng";
}



async function bookingRoomDetail(id) {
    var url = 'http://localhost:8080/api/booking-room/public/find-by-booking?id='+id;
    const response = await fetch(url, {
        method: 'POST'
    });
    var list = await response.json();
    var main = '';
    for(i=0; i<list.length; i++){
        main +=
            `<tr>
            <td><img src="${list[i].room.image}" class="imgdetailacc"></td>
            <td>${list[i].room.name}</td>
            <td>${formatmoney(list[i].price)} / Ngày</td>
        </tr>`
    }
    document.getElementById("listBookingRoom").innerHTML = main;
}



function loadTrangThai(name){
    if(name == "NOT_PAID"){
        return "<span class='dadatcoc'>Chưa thanh toán</span>";
    }
    if(name == "PAID"){
        return "<span class='dathanhtoan'>Đã thanh toán</span>";
    }
    if(name == "CANCELLED"){
        return "<span class='dahuy'>Đã hủy</span>";
    }
}